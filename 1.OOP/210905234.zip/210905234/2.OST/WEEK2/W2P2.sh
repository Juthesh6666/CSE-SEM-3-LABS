echo This file is $0
cd $1
ls $2
echo Done