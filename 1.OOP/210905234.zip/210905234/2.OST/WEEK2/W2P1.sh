echo This file is $0
ls -l *.?
echo Done