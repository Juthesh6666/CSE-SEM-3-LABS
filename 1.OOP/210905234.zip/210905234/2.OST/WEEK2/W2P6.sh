echo This file is $0
cp $echo $ls $1 $2
echo Done