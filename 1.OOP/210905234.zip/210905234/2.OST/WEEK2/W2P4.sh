echo This file is $0
echo The number of files in this directory are
ls | wc -l
echo Done