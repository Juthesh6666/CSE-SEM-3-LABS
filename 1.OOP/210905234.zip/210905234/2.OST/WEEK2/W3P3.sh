echo This file is $0
echo The number of users logged on to the system are
who | wc -l
echo Done