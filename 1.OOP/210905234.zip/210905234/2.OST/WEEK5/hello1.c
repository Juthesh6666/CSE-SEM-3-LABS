#include <stdio.h>
int main() {

	int n;
	printf("Input a number ");
	scanf("%d",&n);
	printf("The input +1 is %d",(n+1));
	return 0;
}