#include "maths.h"
#include <stdio.h>
int add(int a, int b) {
	printf("The addition is ");
	return a+b;
}
