#include "maths.h"
#include <stdio.h>
int sub(int a, int b) {
	printf("The subtraction results in:");
	return a-b;
}
