int add(int, int);
int sub(int, int);
int square(int);
int push(int *, int, int, int);
int pop(int *, int);
void display(int *, int);
